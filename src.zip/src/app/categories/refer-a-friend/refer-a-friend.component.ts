import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refer-a-friend',
  templateUrl: './refer-a-friend.component.html',
  styleUrls: ['./refer-a-friend.component.scss']
})
export class ReferAFriendComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
