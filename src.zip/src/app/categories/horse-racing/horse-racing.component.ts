import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-horse-racing',
  templateUrl: './horse-racing.component.html',
  styleUrls: ['./horse-racing.component.scss']
})
export class HorseRacingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
