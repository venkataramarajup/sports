import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-rules',
  templateUrl: './all-rules.component.html',
  styleUrls: ['./all-rules.component.scss']
})
export class AllRulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
