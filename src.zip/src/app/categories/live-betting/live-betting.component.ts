import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-betting',
  templateUrl: './live-betting.component.html',
  styleUrls: ['./live-betting.component.scss']
})
export class LiveBettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
