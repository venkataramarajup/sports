import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-help-center-category',
  templateUrl: './help-center-category.component.html',
  styleUrls: ['./help-center-category.component.scss']
})
export class HelpCenterCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
