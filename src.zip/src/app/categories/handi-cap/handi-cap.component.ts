import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-handi-cap',
  templateUrl: './handi-cap.component.html',
  styleUrls: ['./handi-cap.component.scss']
})
export class HandiCapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
