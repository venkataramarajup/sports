import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payout-policies',
  templateUrl: './payout-policies.component.html',
  styleUrls: ['./payout-policies.component.scss']
})
export class PayoutPoliciesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
