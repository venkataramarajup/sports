import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roll-over-rules',
  templateUrl: './roll-over-rules.component.html',
  styleUrls: ['./roll-over-rules.component.scss']
})
export class RollOverRulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
