import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deposit-policies',
  templateUrl: './deposit-policies.component.html',
  styleUrls: ['./deposit-policies.component.scss']
})
export class DepositPoliciesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
