import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-racebook-rules',
  templateUrl: './racebook-rules.component.html',
  styleUrls: ['./racebook-rules.component.scss']
})
export class RacebookRulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
