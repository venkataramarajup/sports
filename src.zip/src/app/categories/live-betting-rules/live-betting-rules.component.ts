import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-betting-rules',
  templateUrl: './live-betting-rules.component.html',
  styleUrls: ['./live-betting-rules.component.scss']
})
export class LiveBettingRulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
